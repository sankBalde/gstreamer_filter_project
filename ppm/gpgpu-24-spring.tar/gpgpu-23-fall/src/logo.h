#pragma once
#include <cstdint>

extern "C"
{

    constexpr int logo_width = 430;
    constexpr int logo_height = 291;
    extern const uint8_t logo_data[];

}